import BasicForm from './components/BasicForm';
import SimpleInput from './components/SimpleInput';
import { useState } from 'react';

function App() {

  const [users, setUsers] = useState([]);

  const getUsers = () => {
    
  }

  return (
    <div className="app">
      {/* <SimpleInput /> */}
      <BasicForm />
    </div>
  );
}

export default App;
