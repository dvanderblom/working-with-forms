import { useState, useEffect } from 'react';

export const useFormValidator = (fName, lName, email) => {

  const [firstNameIsValid, setFirstNameIsValid] = useState(false);
  const [lastNameIsValid, setLastNameIsValid] = useState(false);
  const [emailIsValid, setEmailIsValid] = useState(false);
  const [formIsValid, setFormIsValid] = useState(false);

  useEffect(() => {
    let intervalID = setInterval(() => {
      if(fName.length > 0 && !containsSpecialChars(fName)) {
        setFirstNameIsValid(true);
      } else setFirstNameIsValid(false);
  
      if(lName.length > 0 && !containsSpecialChars(lName)) { 
        setLastNameIsValid(true);
      } else setLastNameIsValid(false);
  
      if(email.length > 0 && email.includes('@')) {
        setEmailIsValid(true);
      } else setEmailIsValid(false);

      if(email.length === 0 && !email.includes('@')) {
        setEmailIsValid(false); 
      } else setEmailIsValid(true);

      if(fName.length > 0 && lName.length > 0 && email.length > 0 && email.includes('@') && !containsSpecialChars(fName) && !containsSpecialChars(lName)) {
        setFormIsValid(true);
      } else setFormIsValid(false);
    
    }, 500);
    
    return () => clearInterval(intervalID);
  }, [fName, lName, email])

  return { firstNameIsValid, lastNameIsValid, emailIsValid, formIsValid }
}

function containsSpecialChars(str) {
  const specialChars = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
  return specialChars.test(str);
}

export const useError = (fName, lName, email) => {

  const { fNameIsValid, lNameIsValid, emailIsValid, formIsValid } = useFormValidator(fName, lName, email);
  console.log()

  useEffect(() => {
    console.log(
      'First name: ' + fNameIsValid, 
      '\nLast name: ' + lNameIsValid, 
      '\nEmail: ' + emailIsValid, 
      '\nForm is valid: ' + formIsValid
    );
  }, [email]);

  let errorMessage;

  if(!fNameIsValid && lNameIsValid && emailIsValid) errorMessage = 'Please enter a valid first name';
  if(!lNameIsValid && fName.length === 0 && email.length === 0) errorMessage = 'Please enter a valid last name';
  if(!emailIsValid && fName.length === 0 && lName.length === 0) errorMessage = 'Please enter a valid email address';
  if(!fNameIsValid && !lNameIsValid && email.length === 0) errorMessage = 'Please enter a valid first and last name';
  if(!fNameIsValid && !emailIsValid && lName.length === 0) errorMessage = 'Please enter valid first name and email address';
  if(lNameIsValid && emailIsValid && fName.length === 0) errorMessage = 'Please enter valid last name and email address';

  return errorMessage;
}

export default useError;
