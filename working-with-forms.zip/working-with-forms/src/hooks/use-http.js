const useHttp = () => {

  const fetchData = async () => {
    const response = await fetch('https://working-with-react-forms-default-rtdb.europe-west1.firebasedatabase.app/users.json');
    const data = await response.json();

    let transformedData = data.map(dataPoint => {
      
    });    
  }

  return { fetchData }
}

export default useHttp;