import { useState, useRef } from 'react';
import {useFormValidator, useError} from '../hooks/use-form-validator';

const STYLES = {
  VALID: '1px solid green',
  INVALID: '1px solid red',
}

const BasicForm = (props) => {
  const firstNameRef = useRef('');
  const lastNameRef = useRef('');
  const emailRef = useRef('');

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
 
  const { firstNameIsValid, lastNameIsValid, emailIsValid, formIsValid } = useFormValidator(firstName, lastName, email);

  const errorMessage = useError(firstName, lastName, email);

  const submitForm = (event) => {
    event.preventDefault();

    console.log(firstName, lastName, email);

    setFirstName('');
    setLastName('');
    setEmail('');
  }

  const handleFNameChange = () => {
    const firstName = firstNameRef.current.value;
    setFirstName(firstName);
  }

  const handleLNameChange = () => {
    const lastName = lastNameRef.current.value;
    setLastName(lastName);
  }

  const handleEmailChange = () => {
    const email = emailRef.current.value;
    setEmail(email);
  }

  return (
    <form onSubmit={submitForm}>
      <div className='control-group'>
        <div className='form-control'>
          <label htmlFor='first-name'>First Name</label>
          <input 
            type='text' 
            id='first-name' 
            style={{border: firstNameIsValid ? STYLES.VALID : firstName.length === 0 ? '' : STYLES.INVALID }}
            value={firstName} ref={firstNameRef} 
            placeholder='John'
            onChange={handleFNameChange}
          />
        </div>
        <div className='form-control'>
          <label htmlFor='last-name'>Last Name</label>
          <input 
            type='text' 
            id='last-name' 
            style={{border: lastNameIsValid ? STYLES.VALID : lastName.length === 0 ? '' : STYLES.INVALID}} 
            value={lastName} 
            ref={lastNameRef} 
            placeholder='Doe'
            onChange={handleLNameChange}
          />
        </div>
      </div>
      <div className='form-control'>
        <label htmlFor='email'>E-Mail Address</label>
        <input 
          type='text' 
          id='email' 
          style={{border: emailIsValid ? STYLES.VALID : email.length === 0 ? '' : STYLES.INVALID}} 
          value={email} 
          ref={emailRef} 
          placeholder='youremailaddress@gmail.com'
          onChange={handleEmailChange}
        />
      </div>
      <div className='form-actions'>
        <p style={{color: formIsValid ? 'green' : 'red'}}>
          {firstName.length === 0 && lastName.length === 0 && email.length === 0 ? '' : !formIsValid ? errorMessage : 'Ready to submit'}
        </p>
        <button disabled={!formIsValid} style={{backgroundColor: formIsValid ? 'blue' : 'grey', border: formIsValid ? 'blue' : 'grey'}} type='submit'>
          Submit
        </button>        
      </div>
    </form>
  );
};

export default BasicForm;

